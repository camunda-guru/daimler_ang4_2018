import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {AppComponent} from "./app.component";
import {BrowserModule} from "@angular/platform-browser";
import {MenuComponent} from "./menu/menu.menucomponent";
import {MenuService} from "./services/menuservice";
import {MatIconModule, MatMenuModule} from "@angular/material";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";


@NgModule({
    imports:[BrowserModule,CommonModule,MatMenuModule,
        MatIconModule,BrowserAnimationsModule],
    declarations:[AppComponent,MenuComponent],
    providers:[MenuService],
    bootstrap:[AppComponent]
})
export class AppModule
{

}