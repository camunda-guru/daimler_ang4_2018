import {NgModule} from "@angular/core";
import {CommonModule} from "@angular/common";
import {AppComponent} from "./app.component";
import {BrowserModule} from "@angular/platform-browser";
import {MenuComponent} from "./menu/menu.menucomponent";
import {MenuService} from "./services/menuservice";
import {
    MatButtonModule, MatDialogModule, MatFormFieldModule, MatIconModule, MatInputModule, MatMenuModule,
    MatPaginatorModule,
    MatRadioModule, MatSelectModule, MatSnackBarModule,
    MatSortModule,
    MatTableModule
} from "@angular/material";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {AppRouting} from "./app.routing";
import {DashboardComponent} from "./dashboard/dashboard.component";
import {NewRequestComponent, SaveRecordComponent} from "./newrequest/newrequest.component";
import {AccountsComponent} from "./accounts/accounts.component";
import {AdminComponent} from "./admin/admin.component";
import {CountryService} from "./services/countryservice";
import {HttpClientModule} from "@angular/common/http";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {ShowDialogComponent} from "./accounts/accounts.showdialog";


@NgModule({
    imports:[BrowserModule,CommonModule,MatMenuModule,
        MatIconModule,MatButtonModule,BrowserAnimationsModule,AppRouting,HttpClientModule, MatTableModule,
        MatSortModule,
        MatPaginatorModule,MatFormFieldModule,MatInputModule,ReactiveFormsModule,
        MatRadioModule,MatSelectModule,
    FormsModule,MatSnackBarModule,MatDialogModule],
    declarations:[AppComponent,MenuComponent,DashboardComponent,NewRequestComponent,
        AccountsComponent,AdminComponent,SaveRecordComponent,ShowDialogComponent],
    entryComponents: [SaveRecordComponent,ShowDialogComponent],
    providers:[MenuService,CountryService],
    bootstrap:[AppComponent]
})
export class AppModule
{

}