import {Component} from "@angular/core";


@Component({
    selector:'daimler-home',
    templateUrl:'./app/app.component.html',
    styleUrls:['./app/app.component.css']
})
export class AppComponent
{

    private logoPath:string;
    private bannerPath:string;

    constructor()
    {
        this.logoPath="./app/resources/logo.jpg";
        this.bannerPath="./app/resources/banner1.jpg";
    }


}