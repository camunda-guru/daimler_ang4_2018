import {RouterModule, Routes} from "@angular/router";
import {DashboardComponent} from "./dashboard/dashboard.component";
import {NewRequestComponent} from "./newrequest/newrequest.component";
import {AccountsComponent} from "./accounts/accounts.component";
import {AdminComponent} from "./admin/admin.component";
import {NgModule} from "@angular/core";


var routes:Routes=[{
    path:'DashBoard',
    component:DashboardComponent
},
    {
        path:'NewRequest',
        component:NewRequestComponent
    },
    {
        path:'Accounts',
        component:AccountsComponent
    },
    {
        path:'Admin',
        component:AdminComponent
    },
]


@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class AppRouting
{

}