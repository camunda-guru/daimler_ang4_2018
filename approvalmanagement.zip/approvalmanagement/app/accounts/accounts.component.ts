import {Component} from "@angular/core";


@Component({
    selector:'daimler-accounts',
    templateUrl:'./app/accounts/accounts.component.html',
    styleUrls:['./app/accounts/accounts.component.css']
})
export class AccountsComponent
{

}