import {Component} from "@angular/core";


@Component({


    templateUrl:'./app/admin/admin.component.html',
    styleUrls:['./app/admin/admin.component.css']

})
export class AdminComponent
{

}