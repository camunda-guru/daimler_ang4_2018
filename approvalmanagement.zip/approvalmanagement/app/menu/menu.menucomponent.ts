import {Component, OnInit} from "@angular/core";
import {MenuService} from "../services/menuservice";


@Component({
    selector:'daimler-menu',
    templateUrl:'./app/menu/menu.menucomponent.html',
    styleUrls:['./app/menu/menu.menucomponent.css']
})
export class MenuComponent implements OnInit
{

    private daimlerMenu:any;
    //dependency injection @ constructor level
    constructor(public menuService:MenuService)
    {

    }


    ngOnInit()
    {
      this.daimlerMenu=this.menuService.getMenuItems();
    }

}