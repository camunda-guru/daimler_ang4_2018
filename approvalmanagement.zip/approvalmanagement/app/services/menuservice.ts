import {Injectable} from "@angular/core";
import {Menu} from "../models/menu";
import {menuData} from "../models/menuarray";



@Injectable()
export class MenuService
{

    getMenuItems():Menu[]
        {
        return menuData;
       }



}