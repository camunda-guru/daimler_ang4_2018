import {Menu} from "./menu";


export var menuData:Menu[]=[
    new Menu(1,"DashBoard","dashboard"),
    new Menu(2,"NewRequest","touch_app"),
    new Menu(3,"Accounts","account_box"),
    new Menu(4,"Admin","person_add")
]