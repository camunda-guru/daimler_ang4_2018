export class Menu
{
    private menuCode:number;
    private name:string;
    private iconName:string;
    constructor(id:number,mname:string,icname:string)
    {
        this.menuCode=id;
        this.name=mname;
        this.iconName=icname;

    }

    get IconName():string
    {
        return this.iconName;
    }
    get MenuCode():number
    {
        return this.menuCode;
    }

    get Name():string
    {
        return this.name;
    }
}