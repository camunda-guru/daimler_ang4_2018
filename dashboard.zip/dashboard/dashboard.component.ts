import {AfterViewInit, Component, OnInit, ViewChild} from "@angular/core";
import {CountryService} from "../services/countryservice";
import {MatPaginator, MatSort, MatTableDataSource} from "@angular/material";
import {DataSource} from "@angular/cdk/collections";
import {Observable} from "rxjs/Observable";
import * as jspdf from 'jspdf';
import * as html2canvas from 'html2canvas';

@Component({
    selector:'daimler-dashboard',
    templateUrl:'./app/dashboard/dashboard.component.html',
    styleUrls:['./app/dashboard/dashboard.component.css']
})
export class DashboardComponent implements OnInit,AfterViewInit
{

    @ViewChild(MatSort) sort: MatSort;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    private countries:any;

    constructor(public countryService:CountryService)
    {

    }

    displayedColumns: string[] = ['name', 'nativeName', 'population', 'area'];
    tableSource=new MatTableDataSource();

    ngOnInit()
    {

        this.countryService.getCountries().subscribe(response=>{
            this.countries=response;
            console.log(this.countries);
            //this.tableSource=
            this.tableSource.data = response;
            //this.tableSource.sort = this.sort;
            //this.tableSource.paginator = this.paginator;
        })


    }

    ngAfterViewInit()
    {
        this.tableSource.paginator = this.paginator;
        this.tableSource.sort = this.sort;

    }

    applyFilter(filterValue: string) {
        filterValue = filterValue.trim();
        filterValue = filterValue.toLowerCase();
        this.tableSource.filter = filterValue;
    }

    public captureScreen()
    {
        var data = document.getElementById('contentToConvert');
        html2canvas(data).then(canvas => {
            // Few necessary setting options
            var imgWidth = 208;
            var pageHeight = 295;
            var imgHeight = canvas.height * imgWidth / canvas.width;
            var heightLeft = imgHeight;

            const contentDataURL = canvas.toDataURL('image/png')
            let pdf = new jspdf('p', 'mm', 'a4'); // A4 size page of PDF
            var position = 0;
            pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight)
            pdf.save('MYPdf.pdf'); // Generated PDF
        });
    }
}

/*

export class TableDataSource extends DataSource<any>{

    constructor(private countryServiceObj:CountryService)
    {
        super()
    }
    connect():Observable<any[]>
    {
        return this.countryServiceObj.getCountries();
    }
    disconnect() {}
}
*/

